package com.example.data.local

import com.squareup.moshi.JsonClass

enum class FtthNodeType(val label: String, val category: String) {
    POTEAU("Poteau", "Appui aérien / Façade"),
    CHAMBRE("Chambre", "Génie civil souterrain"),
    BOITIER("Boîtier", "BPE / PBO / PB / Autre"),
    SRO("SRO", "Sous-Répartiteur Optique"),
    IMMEUBLE("Immeuble", "Bâtiment collectif"),
    VILLA("Villa / Pavillon", "Habitation individuelle")
}

enum class NodeStatus(val label: String) {
    EXISTANT("Existant"),
    A_POSER("À poser"),
    A_REMPLACER("À remplacer"),
    A_DEPOSER("À déposer")
}

enum class NodeConformity(val label: String) {
    CONFORME("Conforme"),
    NON_CONFORME("Non conforme")
}

@JsonClass(generateAdapter = true)
data class FtthNodeEntity(
    val id: String,
    val type: FtthNodeType,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val status: NodeStatus = NodeStatus.EXISTANT,
    val etat: NodeConformity = NodeConformity.CONFORME,
    val address: String = "",
    val hasBoitierFtth: Boolean = false, // Non, Oui (sauf Villa et SRO)
    val notes: String = "", // Commentaire
    val technicianName: String = "Tech-01 (Moi)",
    val photoCount: Int = 0,
    val updatedAt: Long = System.currentTimeMillis(),

    // Spécifique Poteau
    val poleNature: String = "béton", // bois, métal, béton, façade
    val poleHeight: Int = 8, // 7, 8, 9, 10

    // Spécifique Chambre
    val chamberType: String = "L2T", // L0T, L1T, L2T, K1C, K2C, etc.

    // Spécifique Boîtier
    val boitierType: String = "PBO", // BPE, PBO, PB, autre
    val isSaturated: Boolean = false, // Saturé : Non, Oui
    val boitierSupport: String = "Poteau", // Poteau, Chambre, Façade, Sous-Sol

    // Spécifique SRO
    val sroType: String = "armoire de rue", // armoire de rue, local
    val sroCapacity: String = "360 FO", // Capacité (ex: 144 FO, 360 FO, 720 FO, 1000 FO)

    // Spécifique Immeuble
    val buildingFloors: Int = 4, // Nombre étages
    val buildingDwellings: Int = 16, // Nombre logement
    val hasLocalTechnique: Boolean = true, // Local technique : Oui/Non
    val hasGaineMontante: Boolean = true, // Gaine montante : oui/non
    val syndicAuthorization: String = "Accord obtenu", // Accord obtenu, En attente, Refusé
    val syndicContact: String = "", // Contact syndic (facultatif)
    val buildingConnectionMode: String = "souterrain", // façade, souterrain, aérien

    // Spécifique Villa/Pavillon
    val villaConnectionMode: String = "aérien" // aérien, souterrain, façade
)

@JsonClass(generateAdapter = true)
data class FtthLinkEntity(
    val id: String,
    val fromNodeId: String,
    val toNodeId: String,
    val cableType: String = "Distribution", // Transport, Distribution, Raccordement
    val installationType: String = "Aérien", // Aérien, Souterrain, Façade
    val capacityFO: Int = 24, // 144, 72, 48, 24, 12, 4
    val lengthMeters: Double = 45.0,
    val status: NodeStatus = NodeStatus.EXISTANT,
    val updatedAt: Long = System.currentTimeMillis()
)
