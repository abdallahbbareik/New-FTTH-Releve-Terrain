package com.example.data.local

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import java.io.File

/**
 * Persistance locale en fichiers JSON — pas de base de données.
 *
 * Toutes les données du projet (nœuds, liaisons, et plus tard trajets) sont
 * stockées dans un dossier "Releve-Terrain" propre à l'application, sur le
 * stockage de l'appareil (Android/data/<package>/files/Releve-Terrain), donc
 * sans avoir à demander de permission de stockage.
 */
class LocalFtthStore(context: Context) {

    private val moshi = Moshi.Builder().build()

    val rootDir: File = File(context.getExternalFilesDir(null), "Releve-Terrain").apply { mkdirs() }

    /** Un sous-dossier par point sera créé ici, nommé d'après son identifiant. */
    val photosDir: File = File(rootDir, "Photos").apply { mkdirs() }

    private val nodesFile = File(rootDir, "nodes.json")
    private val linksFile = File(rootDir, "links.json")

    private val nodeListType = Types.newParameterizedType(List::class.java, FtthNodeEntity::class.java)
    private val linkListType = Types.newParameterizedType(List::class.java, FtthLinkEntity::class.java)

    private val nodeAdapter = moshi.adapter<List<FtthNodeEntity>>(nodeListType)
    private val linkAdapter = moshi.adapter<List<FtthLinkEntity>>(linkListType)

    fun loadNodes(): List<FtthNodeEntity> =
        readOrNull(nodesFile)?.let { runCatching { nodeAdapter.fromJson(it) }.getOrNull() } ?: emptyList()

    fun loadLinks(): List<FtthLinkEntity> =
        readOrNull(linksFile)?.let { runCatching { linkAdapter.fromJson(it) }.getOrNull() } ?: emptyList()

    fun saveNodes(nodes: List<FtthNodeEntity>) {
        nodesFile.writeText(nodeAdapter.indent("  ").toJson(nodes))
    }

    fun saveLinks(links: List<FtthLinkEntity>) {
        linksFile.writeText(linkAdapter.indent("  ").toJson(links))
    }

    /** Dossier dédié aux photos d'un point, créé à la demande (nommé d'après l'id du point). */
    fun photoFolderForNode(nodeId: String): File =
        File(photosDir, nodeId).apply { mkdirs() }

    private fun readOrNull(file: File): String? =
        if (file.exists()) file.readText() else null
}
