package com.example.data.repository

import com.example.data.local.DefaultFtthData
import com.example.data.local.FtthLinkEntity
import com.example.data.local.FtthNodeEntity
import com.example.data.local.LocalFtthStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Repository sans base de données : les nœuds et liaisons vivent en mémoire
 * (StateFlow) et sont lus/écrits dans des fichiers JSON locaux via [LocalFtthStore].
 */
class FtthRepository(
    private val store: LocalFtthStore,
    private val appScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val _allNodes = MutableStateFlow<List<FtthNodeEntity>>(emptyList())
    val allNodes: StateFlow<List<FtthNodeEntity>> = _allNodes.asStateFlow()

    private val _allLinks = MutableStateFlow<List<FtthLinkEntity>>(emptyList())
    val allLinks: StateFlow<List<FtthLinkEntity>> = _allLinks.asStateFlow()

    init {
        appScope.launch {
            val loadedNodes = withContext(Dispatchers.IO) { store.loadNodes() }
            val loadedLinks = withContext(Dispatchers.IO) { store.loadLinks() }
            if (loadedNodes.isEmpty() && loadedLinks.isEmpty()) {
                // Premier lancement (aucun fichier existant) : on amorce avec la démo
                _allNodes.value = DefaultFtthData.getDefaultNodes()
                _allLinks.value = DefaultFtthData.getDefaultLinks()
                persistNodes()
                persistLinks()
            } else {
                _allNodes.value = loadedNodes
                _allLinks.value = loadedLinks
            }
        }
    }

    private fun persistNodes() {
        val snapshot = _allNodes.value
        appScope.launch(Dispatchers.IO) { store.saveNodes(snapshot) }
    }

    private fun persistLinks() {
        val snapshot = _allLinks.value
        appScope.launch(Dispatchers.IO) { store.saveLinks(snapshot) }
    }

    suspend fun saveNode(node: FtthNodeEntity, isNew: Boolean = false) {
        val updated = node.copy(updatedAt = System.currentTimeMillis())
        _allNodes.value = _allNodes.value.filterNot { it.id == updated.id } + updated
        persistNodes()
    }

    suspend fun deleteNode(id: String) {
        _allNodes.value = _allNodes.value.filterNot { it.id == id }
        persistNodes()
    }

    suspend fun saveLink(link: FtthLinkEntity) {
        _allLinks.value = _allLinks.value.filterNot { it.id == link.id } + link
        persistLinks()
    }

    suspend fun deleteLink(id: String) {
        _allLinks.value = _allLinks.value.filterNot { it.id == id }
        persistLinks()
    }

    suspend fun resetToDefaultDemo() {
        _allNodes.value = DefaultFtthData.getDefaultNodes()
        _allLinks.value = DefaultFtthData.getDefaultLinks()
        persistNodes()
        persistLinks()
    }

    companion object {
        // Formule de Haversine pour calculer la distance en mètres entre 2 coordonnées GPS
        fun calculateDistanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val r = 6371000.0 // Rayon de la Terre en mètres
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = sin(dLat / 2) * sin(dLat / 2) +
                    cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                    sin(dLon / 2) * sin(dLon / 2)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return r * c
        }
    }
}
